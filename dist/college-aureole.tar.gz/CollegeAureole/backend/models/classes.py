
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, event
from timeutils import now_utc
from sqlalchemy.orm import relationship
from database import Base


class Classes(Base):
    __tablename__ = "classes"
    id = Column(Integer, primary_key=True)
    code_classe = Column(String, nullable=True, unique=True, index=True)
    niveau = Column(String, nullable=False)
    nom = Column(String, nullable=False)
    frais_inscription = Column(Float, nullable=False, default=0.0)
    mensualite = Column(Float, nullable=False, default=0.0)
    id_salle = Column(Integer, ForeignKey("salles.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at = Column(DateTime, nullable=False, default=now_utc)
    updated_at = Column(DateTime, nullable=False, default=now_utc, onupdate=now_utc)

    # Relations
    salle = relationship("Salles", back_populates="classes")
    eleves = relationship("Eleves", back_populates="classe_relation")
    cours_affectations = relationship(
        "AffectationCoursClasse", back_populates="classe", cascade="all, delete-orphan"
    )
    notes = relationship("Notes", back_populates="classe")
    bulletins = relationship("Bulletins", back_populates="classe")
    inscriptions = relationship("Inscriptions", back_populates="classe")
    seances = relationship("Seances", back_populates="classe", cascade="all, delete-orphan")
    echeances = relationship("Echeances", back_populates="classe")

    @property
    def cours(self):
        """Liste des cours affectés à cette classe (via AffectationCoursClasse)."""
        return [a.cours for a in self.cours_affectations]

    @property
    def effectif_actuel(self) -> int:
        return len([e for e in self.eleves if e.statut == "actif"])


@event.listens_for(Classes, "before_insert")
def generer_code_classe(mapper, connection, target):
    """CLA{année de création}{n°} — compteur global."""
    from sqlalchemy.orm import object_session
    from identifiants import generer_code, annee_creation
    session = object_session(target)
    target.code_classe = generer_code(
        connection, Classes.__table__.c.code_classe, "CLA", annee_creation(),
        session=session,
    )
